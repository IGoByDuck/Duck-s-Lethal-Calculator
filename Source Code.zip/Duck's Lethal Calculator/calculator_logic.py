import math
import random

# Global state holders
timesFulfilled = 0
totalLuck = 0.0

def set_total_luck(value):
    global totalLuck
    totalLuck = value

def get_total_luck():
    global totalLuck
    return totalLuck

def set_times_fulfilled(value):
    global timesFulfilled
    timesFulfilled = value

def get_times_fulfilled():
    global timesFulfilled
    return timesFulfilled

def randomizerCurve(x):
    epsilon = 1e-6 
    x = max(min(x, 1 - epsilon), epsilon)
    return math.tanh(math.log(x / (1 - x))) / 2

def quotaIncrease():
    global timesFulfilled, totalLuck
    if timesFulfilled == 0:
        return 130
    quota = 100 * (1 + timesFulfilled ** 2 / 16) * (randomizerCurve(random.random() * abs(totalLuck - 1)) + 1)
    return round(quota)

def overtimeBonus(sellRequire, profitQuota, daysUntilDeadline):
    daysUntilDeadline -= 1
    otBonus = (sellRequire - profitQuota) / 5 + 15 * daysUntilDeadline
    return math.floor(max(0, otBonus))

def creditsGoal(profitTarget, profitQuota, daysUntilDeadline):
    sellRequire = math.ceil((5 * profitTarget + profitQuota - 75 * (daysUntilDeadline - 1)) / 6)
    return max(sellRequire, profitQuota)

def simulate_quotas(n, startQuota=0):
    global timesFulfilled
    results = []
    oldQuota = startQuota
    for _ in range(n):
        quotas = []
        currentQuota = 0
        for _ in range(10000):
            q = quotaIncrease()
            quotas.append(q)
            currentQuota += q
        averageQuota = round((currentQuota / 10000) + oldQuota)
        minQuota = min(quotas) + oldQuota
        maxQuota = max(quotas) + oldQuota
        timesFulfilled += 1
        results.append({
            "number": timesFulfilled,
            "average": averageQuota,
            "min": minQuota,
            "max": maxQuota
        })
        oldQuota = averageQuota
    return results

def single_quota_prediction(current_quota, times_fulfilled):
    global timesFulfilled
    timesFulfilled = times_fulfilled
    quotas = []
    total = 0
    for _ in range(10000):
        q = quotaIncrease()
        quotas.append(q)
        total += q
    avg = round((total / 10000) + current_quota)
    return {
        "average": avg,
        "min": min(quotas) + current_quota,
        "max": max(quotas) + current_quota,
        "next_quota_number": timesFulfilled + 1
    }

def calculate_total_luck(furniture_list):
    furniture_values = {
        "Cozy Lights": 0.005,
        "Television": 0.02,
        "Toilet": 0.01,
        "Shower": 0.015,
        "Record Player": 0.005,
        "Table": 0.004,
        "Romantic Table": 0.005,
        "Signal Translator": -0.012,
        "Loud Horn": 0.0025,
        "Inverse Teleporter": 0.004,
        "Jack O'Lantern": 0.012,
        "Welcome Mat": 0.003,
        "Goldfish": 0.006,
        "Plushie Pajama Man": 0.003,
        "Disco Ball": 0.06
    }
    total = sum(furniture_values.get(item, 0) for item in furniture_list)
    set_total_luck(total)
    return round(total, 6)