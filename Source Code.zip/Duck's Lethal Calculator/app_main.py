import webview
import calculator_logic as logic

class Api:
    def calculate_credits(self, credits_wanted, quota_required, days_left):
        sell = logic.creditsGoal(credits_wanted, quota_required, days_left)
        bonus = logic.overtimeBonus(sell, quota_required, days_left)
        return {
            'sell': sell,
            'bonus': bonus,
            'total': sell + bonus
        }

    def calculate_bonus(self, total_sold, quota_required, days_left):
        bonus = logic.overtimeBonus(total_sold, quota_required, days_left)
        return {
            'bonus': bonus,
            'total': total_sold + bonus
        }

    def simulate_quotas(self, n):
        logic.set_times_fulfilled(0)
        return logic.simulate_quotas(n)

    def predict_next_quota(self, current_quota, times_fulfilled):
        return logic.single_quota_prediction(current_quota, times_fulfilled)

    def calculate_total_luck(self, furniture_list):
        return { "total_luck": logic.calculate_total_luck(furniture_list) }

if __name__ == '__main__':
    api = Api()
    window = webview.create_window(
        "Duck's Lethal Calculator",
        "frontend.html",
        js_api=api,
        width=600,
        height=700,
        resizable=False
    )
    webview.start()